_**Example page include**_

{{< hint type=note >}}
**Example Shortcode**\
Shortcode used in an include page.
{{< /hint >}}

| Head 1 | Head 2 | Head 3 |
| ------ | ------ | ------ |
| 1      | 2      | 3      |
