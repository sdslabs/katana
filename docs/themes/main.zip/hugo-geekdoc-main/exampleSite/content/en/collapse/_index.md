---
title: Collapse
geekdocCollapseSection: true
---

Demo collapsible menu entries.
