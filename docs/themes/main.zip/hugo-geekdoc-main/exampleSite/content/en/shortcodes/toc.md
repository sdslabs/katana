---
title: ToC
---

Simple wrapper to generate a page Table of Content from a shortcode.

**Attributes:**

| Name   | Description                | Default                                                       |
| ------ | -------------------------- | ------------------------------------------------------------- |
| format | format of the returned ToC | <!-- spellchecker-disable -->html<!-- spellchecker-enable --> |

**Usage:**

<!-- prettier-ignore-start -->
```tpl
{{</* toc (format=[html|raw]) */>}}
```
<!-- prettier-ignore-end -->

**Example:**

{{< toc >}}

## Level 1

Dolor sit, sumo unique argument um no. Gracie nominal id xiv. Romanesque acclimates investiture. Ornateness bland it ex enc, est yeti am bongo detract re. Pro ad prompts feud gait, quid exercise emeritus bis e. In pro quints consequent, denim fastidious copious quo ad. Stet probates in duo.

## Level 2

Amalia id per in minimum facility, quid facet modifier ea ma. Ill um select ma ad, en ferric patine sentient vim. Per expendable foreordained interpretations cu, maxim sole pertinacity in ram.

### Level 2.1

Amalia id per in minimum facility, quid facet modifier ea ma. Ill um select ma ad, en ferric patine sentient vim. Per expendable foreordained interpretations cu, maxim sole pertinacity in ram.

#### Level 2.1.1

Amalia id per in minimum facility, quid facet modifier ea ma. Ill um select ma ad, en ferric patine sentient vim.

##### Level 2.1.1.1

In pro quints consequent, denim fastidious copious quo ad.

###### Level 2.1.1.1.1

In pro quints consequent, denim fastidious copious quo ad.

### Level 2.2

Dolor sit, sumo unique argument um no. Gracie nominal id xiv. Romanesque acclimates investiture. Ornateness bland it ex enc, est yeti am bongo detract re. Pro ad prompts feud gait, quid exercise emeritus bis e.

Amalia id per in minimum facility, quid facet modifier ea ma. Ill um select ma ad, en ferric patine sentient vim. Per expendable foreordained interpretations cu, maxim sole pertinacity in ram.
