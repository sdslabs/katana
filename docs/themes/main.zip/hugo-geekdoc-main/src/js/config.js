export const COLOR_THEME_DARK = "dark"
export const COLOR_THEME_LIGHT = "light"
export const COLOR_THEME_AUTO = "auto"
export const THEME = "hugo-geekdoc"
export const TOGGLE_COLOR_THEMES = [COLOR_THEME_AUTO, COLOR_THEME_DARK, COLOR_THEME_LIGHT]
