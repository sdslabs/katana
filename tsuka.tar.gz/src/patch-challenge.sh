git add . > /dev/null 2>&1
git commit -m "$*" > /dev/null 2>&1
git push -u origin master > /dev/null 2>&1
